# Controller

import sqlite3
import tkinter as tk
from tkinter import Menu
from tkinter import messagebox as mb
import customtkinter

from model.model_bd import Modelo
from view.vista_login import Login

class Controlador:
    def __init__(self, raiz):
        self.modelo = Modelo()
        self.vista = Login(raiz)
        self.raiz = raiz
        self.vista.btn_ingresar.configure(command=self.verificar)
        
        
    def verificar(self):
        
        usuario = self.vista.entry_usuario.get().lower()
        contraseña = self.vista.entry_contraseña.get()

        resultado = self.modelo.verificar(usuario, contraseña)
        if resultado:
            print("Acceso concedido.")
            
            from main_gestion_stock import Controlador
            self.menuGestion=Controlador(self.raiz)

        if len(usuario)==0 or len(contraseña)==0:
             print('ERROR')
             mb.showerror('','Usuario/Contraseña no puede estar vacío.')
    
        elif any(a.isdigit() for a in usuario):

            print('ERROR')
            mb.showerror('','Usuario no puede contener números.')
            

        else:
            print("Acceso denegado")
            mb.showerror('','Usuario y/o Contraseña Incorrectos.')
            self.vista.entry_usuario.delete(0, 'end')
            self.vista.entry_contraseña.delete(0, 'end')
          

        

        

        