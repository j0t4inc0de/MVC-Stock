# Controller Gestion

import sqlite3
from tkinter import Menu
import tkinter as tk
from tkinter import messagebox as mb
import customtkinter

from model.model_bd_stock import ModeloStock
from view.vista_gestion_stock import GestionStock

class Controlador:
    def __init__(self, raiz):
        self.modelo = ModeloStock()
        self.vista = GestionStock(raiz, self)

        self.raiz = raiz  # Guardamos una referencia a la ventana raíz
    def irventa(self):
        self.raiz.destroy()
        self.raiz = tk.Tk()  # Crea una nueva ventana raíz
        from view.vista_gestion_ventas import GestionVentas
        self.vistaVentas = GestionVentas(self.raiz, self)  # Abre la nueva vista en la nueva ventana

    def irstock(self):
        self.raiz.destroy()
        self.raiz = tk.Tk()  # Crea una nueva ventana raíz
        from view.vista_gestion_stock import GestionStock
        self.vistaStock = GestionStock(self.raiz, self)  # Abre la nueva vista en la nueva ventana

    def salir(self):
        if mb.askyesno('Salir', 'Esta seguro de salir?'):
            self.raiz.destroy()
