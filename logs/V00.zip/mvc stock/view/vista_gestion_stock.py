# View

import sqlite3
import tkinter as tk
from tkinter import Menu
from tkinter import messagebox as mb
import customtkinter

class GestionStock:
    def __init__(self, raiz, controlador):

        self.frame = tk.Frame(raiz)
        self.frame.place(x=0, y=0, width=800, height=600)
        raiz.title("Gestion de inventario")
        raiz.geometry("800x600")
        self.entry_nombre = customtkinter.CTkEntry(self.frame, placeholder_text="Nombre", text_color=("gray10", "#DCE4EE"),  width=220, height=30)
        self.entry_nombre.pack()

        self.entry_cantidad = customtkinter.CTkEntry(self.frame, placeholder_text="Cantidad", text_color=("gray10", "#DCE4EE"),  width=220, height=30)
        self.entry_cantidad.pack()

        self.entry_precio = customtkinter.CTkEntry(self.frame, placeholder_text="Precio", text_color=("gray10", "#DCE4EE"),  width=220, height=30)
        self.entry_precio.pack()
        
        self.btn_añadir =  customtkinter.CTkButton(self.frame, fg_color="#1874CD", border_width=1, text="Añadir", text_color=("gray10", "#DCE4EE"),  width=100, height=30)
        self.btn_añadir.pack()
        self.btn_modificar =  customtkinter.CTkButton(self.frame, fg_color="#1874CD", border_width=1, text="Modificar", text_color=("gray10", "#DCE4EE"),  width=100, height=30)
        self.btn_modificar.pack()
        self.btn_eliminar =  customtkinter.CTkButton(self.frame, fg_color="#1874CD", border_width=1, text="Eliminar", text_color=("gray10", "#DCE4EE"),  width=100, height=30)
        self.btn_eliminar.pack()
    
        self.menu = Menu(self.frame)
        self.menuinicio = Menu(self.menu, tearoff=0)
        self.menu.add_cascade(label='Inicio', menu=self.menuinicio)
        self.menuinicio.add_command(label='Gestion de venta', command=controlador.irventa)
        self.menuinicio.add_command(label='Salir', command=controlador.salir)
        raiz.config(menu=self.menu)
