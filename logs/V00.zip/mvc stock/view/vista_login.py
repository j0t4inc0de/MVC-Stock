# View

import sqlite3
import tkinter as tk
from tkinter import messagebox as mb
import customtkinter

class Login:
    def __init__(self, raiz):

        self.frame = tk.Frame(raiz)
        self.frame.place(x=0, y=0, width=400, height=600)
        raiz.title("AlaNorte")
        raiz.geometry("400x600")

        self.entry_usuario = customtkinter.CTkEntry(self.frame, placeholder_text="Usuario", text_color=("gray10", "#DCE4EE"),  width=220, height=30)
        self.entry_usuario.place(x=90,y=230)

        self.entry_contraseña = customtkinter.CTkEntry(self.frame, placeholder_text="Contraseña", text_color=("gray10", "#DCE4EE"),  width=220, height=30)
        self.entry_contraseña.place(x=90,y=280)
        
        self.btn_ingresar =  customtkinter.CTkButton(self.frame, fg_color="#1874CD", border_width=1, text="INGRESAR", text_color=("gray10", "#DCE4EE"),  width=100, height=30)
        self.btn_ingresar.place(x=150, y=330)