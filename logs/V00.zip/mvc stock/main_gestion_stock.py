# Main

import sqlite3
import tkinter as tk
from tkinter import Menu
from tkinter import messagebox
import customtkinter

from controller.controlador_gestion import Controlador
if __name__ == "__main__":
    raiz = tk.Tk()
    app = Controlador(raiz)
    raiz.mainloop()