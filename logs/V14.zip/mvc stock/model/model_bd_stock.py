# Model Stock

import sqlite3
import tkinter as tk
from tkinter import messagebox as mb
import customtkinter
from PIL import Image, ImageTk
# Modelo
class ModeloStock:
    def __init__(self):
        # #Tabla Inventario
        self.conn = sqlite3.connect('data/inventario.db')
        self.cur = self.conn.cursor()
        self.cur.execute('''CREATE TABLE IF NOT EXISTS inventario (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT, cantidad INTEGER, precio REAL)''')
        self.conn.commit()