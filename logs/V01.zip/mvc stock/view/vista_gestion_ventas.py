# View

import sqlite3
import tkinter as tk
from tkinter import Menu
from tkinter import messagebox as mb
import customtkinter

class GestionVentas:
    def __init__(self, raiz, controlador):

        self.frame = tk.Frame(raiz)
        self.frame.place(x=0, y=0, width=800, height=600)
        raiz.title("Gestion de ventas")
        raiz.geometry("1080x600")
        titulo = customtkinter.CTkLabel(self.frame, text="Gestion de ventas", width=120, height=25, fg_color=("white", "gray75"), corner_radius=8)
        titulo.place(relx=0.5, rely=0.5, anchor=tk.CENTER)
    
        self.menu = Menu(self.frame)
        self.menuinicio = Menu(self.menu, tearoff=0)
        self.menu.add_cascade(label='Inicio', menu=self.menuinicio)
        self.menuinicio.add_command(label='Ir a Stock', command=controlador.irstock)
        self.menuinicio.add_command(label='Salir', command=controlador.salir)
        raiz.config(menu=self.menu)
