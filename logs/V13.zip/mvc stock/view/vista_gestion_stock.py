#View Gestion Stock
import sqlite3
import tkinter as tk
from tkinter import Menu, ttk
from tkinter import messagebox as mb
import customtkinter
from PIL import Image, ImageTk

class GestionStock:
    def __init__(self, raiz, controlador):
        raiz.title("Gestion de inventario")
        raiz.geometry("1080x600")
        raiz.configure(bg="#2B2B2B")
        # self.side_frame = customtkinter.CTkFrame(raiz, width=200)
        # self.side_frame.pack(side='left', fill='both')
        # self.side_frame.pack_propagate(0)

        self.entry_nombre = customtkinter.CTkEntry(raiz, placeholder_text="Nombre", text_color=("gray10", "#DCE4EE"),  width=220, height=30)
        self.entry_nombre.place(x=230,y=420)
        self.entry_cantidad = customtkinter.CTkEntry(raiz, placeholder_text="Cantidad", text_color=("gray10", "#DCE4EE"),  width=220, height=30)
        self.entry_cantidad.place(x=230,y=480)
        self.entry_precio = customtkinter.CTkEntry(raiz, placeholder_text="Precio", text_color=("gray10", "#DCE4EE"),  width=220, height=30)
        self.entry_precio.place(x=230,y=540)
        self.entry_buscador = customtkinter.CTkEntry(raiz, placeholder_text="Buscador", text_color=("gray10", "#DCE4EE"),  width=380, height=30)
        self.entry_buscador.place(x=230, y=5)

        self.imagen_lupa = Image.open("view/images/lupa.png")
        self.imagen_lupa = ImageTk.PhotoImage(self.imagen_lupa)
        self.label_lupa = tk.Button(raiz, image=self.imagen_lupa, borderwidth=0, highlightthickness=0)
        self.label_lupa.place(x=620,y=2)

        self.btn_añadir =  customtkinter.CTkButton(raiz, text="Ingresar", fg_color="#007FFF", border_width=1, text_color="#F8F8FF", hover_color="#008B45", border_color="#1A1A1A", width=90, height=30)
        self.btn_añadir.place(x=40, y=420)
        self.btn_modificar =  customtkinter.CTkButton(raiz, text="Modificar", fg_color="#007FFF", border_width=1, text_color="#F8F8FF", hover_color="#CD9B1D", border_color="#1A1A1A", width=90, height=30)
        self.btn_modificar.place(x=40, y=480)
        self.btn_eliminar =  customtkinter.CTkButton(raiz, text="Eliminar", fg_color="#007FFF", border_width=1, text_color="#F8F8FF", hover_color="#F08080", border_color="#1A1A1A", width=90, height=30)
        self.btn_eliminar.place(x=40, y=540)

        # self.menu = Menu(raiz)
        # self.menuinicio = Menu(self.menu, tearoff=0)
        # self.menu.add_cascade(label='Inicio', menu=self.menuinicio)
        # self.menuinicio.add_command(label='Ir a Ventas', command=controlador.irventa)
        # self.menuinicio.add_command(label='Salir', command=controlador.salir)
        # raiz.config(menu=self.menu)

        style = ttk.Style(raiz)
        style.theme_use("clam")
        style.configure("Treeview", background="#2B2B2B", fieldbackground="#2B2B2B", foreground="white")
        
        tree_frame = tk.Frame(raiz)
        tree_frame.place(x=230, y=43)
        tree = ttk.Treeview(raiz, show='headings')
        tree["columns"]=("#1", "#2", "#3")
        tree.column("#1", width=275)
        tree.column("#2", width=275)
        tree.column("#3", width=275)
        tree.heading("#1", text="Nombre")
        tree.heading("#2", text="Cantidad")
        tree.heading("#3", text="Precio")
        tree.place(x=230, y=43, height=540)